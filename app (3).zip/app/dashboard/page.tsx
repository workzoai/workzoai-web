"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  BarChart3,
  Bot,
  CheckCircle2,
  ClipboardCheck,
  FileText,
  Mail,
  Mic,
  Search,
  Settings,
  Sparkles,
} from "lucide-react";
import {
  readCandidateIdentity,
  syncCandidateIdentityFromSetup,
  type WorkZoCandidateIdentity,
} from "@/lib/workzoCandidateIdentity";
import { readLatestInterviewSetup } from "@/lib/workzoInterviewSetup";

const navItems = [
  { label: "Dashboard", href: "/dashboard", icon: Sparkles, active: true },
  { label: "Improve CV", href: "/cv", icon: FileText },
  { label: "Cover Letter", href: "/cover-letter", icon: Mail },
  { label: "Find Jobs", href: "/jobs", icon: Search },
  { label: "Real Interview AI", href: "/interview", icon: Mic },
  { label: "Results", href: "/results", icon: ClipboardCheck },
  { label: "Settings", href: "/settings", icon: Settings },
];

function firstName(fullName: string) {
  const clean = String(fullName || "Candidate").trim();
  if (!clean || /^candidate$/i.test(clean)) return "Candidate";
  return clean.split(/\s+/)[0];
}

function isRealCandidateName(name = "") {
  return Boolean(name.trim()) && !/^candidate$/i.test(name.trim());
}

function WorkZoLogo() {
  return (
    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 shadow-lg shadow-cyan-500/20">
      <CheckCircle2 className="h-8 w-8 text-slate-950" strokeWidth={3} />
    </div>
  );
}

export default function DashboardPage() {
  const [candidate, setCandidate] = useState<WorkZoCandidateIdentity>(() => readCandidateIdentity());

  useEffect(() => {
    const setup = readLatestInterviewSetup();
    const synced = syncCandidateIdentityFromSetup(setup);
    const latest = isRealCandidateName(synced.name) ? synced : readCandidateIdentity();
    setCandidate(latest);
  }, []);

  const displayName = isRealCandidateName(candidate.name) ? candidate.name : "Candidate";
  const displayFirstName = firstName(displayName);
  const targetChip = candidate.headline || "Career workspace";

  const progress = useMemo(
    () => [
      { label: "CV uploaded", done: isRealCandidateName(candidate.name) },
      { label: "Job context added", done: true },
      { label: "Interview prepared", done: true },
      { label: "Feedback reviewed", done: true },
    ],
    [candidate.name],
  );

  return (
    <main className="min-h-screen bg-[#020817] px-4 py-5 text-white sm:px-6">
      <div className="mx-auto grid max-w-[1480px] gap-6 xl:grid-cols-[290px_minmax(0,1fr)]">
        <aside className="rounded-[28px] border border-white/10 bg-[#071120]/95 p-5 shadow-2xl shadow-black/25 xl:sticky xl:top-5 xl:h-[calc(100vh-40px)]">
          <Link href="/dashboard" className="mb-8 flex items-center gap-4">
            <WorkZoLogo />
            <div className="min-w-0">
              <p className="text-2xl font-black tracking-tight">
                WorkZo <span className="text-blue-300">AI</span>
              </p>
              <p className="text-xs font-black uppercase tracking-[0.25em] text-cyan-200">
                Career OS
              </p>
            </div>
          </Link>

          <nav className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={[
                    "flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-black transition",
                    item.active
                      ? "bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-lg shadow-blue-600/20"
                      : "text-slate-300 hover:bg-white/8",
                  ].join(" ")}
                >
                  <Icon className="h-5 w-5 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <section className="mt-8 rounded-3xl border border-cyan-300/15 bg-cyan-400/8 p-4">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600">
                <Bot className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <p className="font-black">Work-O-Bot</p>
                <p className="text-xs font-bold text-cyan-200">Career assistant</p>
              </div>
            </div>
            <button className="w-full rounded-2xl bg-white/10 px-4 py-3 text-sm font-black text-white transition hover:bg-white/15">
              Open assistant
            </button>
          </section>
        </aside>

        <section className="min-w-0 space-y-6">
          <header className="rounded-[30px] border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 p-6 shadow-2xl shadow-blue-950/20 lg:p-8">
            <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-start">
              <div className="min-w-0">
                <p className="mb-3 text-xs font-black uppercase tracking-[0.34em] text-cyan-200 sm:text-sm">
                  Career Workspace
                </p>
                <h1 className="text-[42px] font-black leading-[0.98] tracking-tight sm:text-6xl xl:text-7xl">
                  Welcome back, {displayFirstName} <span className="inline-block">👋</span>
                </h1>
                <p className="mt-5 max-w-4xl text-base leading-8 text-slate-300 sm:text-lg">
                  Your focused workspaces are ready for {displayName}. Improve the CV,
                  prepare applications, find jobs, or enter a realistic recruiter room.
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  <span className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-black text-slate-200">
                    {targetChip}
                  </span>
                  {candidate.email ? (
                    <span className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-black text-slate-200">
                      {candidate.email}
                    </span>
                  ) : null}
                </div>
              </div>

              <Link
                href="/interview"
                className="inline-flex items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-violet-600 px-7 py-4 text-base font-black text-white shadow-xl shadow-blue-600/25 transition hover:scale-[1.01]"
              >
                Start Real Interview
                <span className="text-2xl leading-none">→</span>
              </Link>
            </div>
          </header>

          <div className="grid gap-6 2xl:grid-cols-[1.05fr_0.95fr]">
            <section className="rounded-[30px] border border-cyan-300/15 bg-gradient-to-br from-cyan-950/35 via-slate-950 to-violet-950/45 p-6 lg:p-8">
              <span className="inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.25em] text-cyan-200">
                Hero Feature
              </span>

              <div className="mt-8 grid gap-7 lg:grid-cols-[0.86fr_1fr] lg:items-center">
                <div className="min-w-0">
                  <h2 className="text-5xl font-black leading-[0.95] tracking-tight sm:text-6xl">
                    Real<br />Interview<br />AI
                  </h2>
                  <p className="mt-7 max-w-md text-lg leading-8 text-slate-300">
                    Practice with an AI recruiter that reads {displayFirstName}’s CV and job,
                    asks follow-ups, applies pressure, and shows where recruiter trust changed.
                  </p>
                </div>

                <div className="rounded-[28px] border border-white/10 bg-black/20 p-5">
                  <p className="mb-5 text-xs font-black uppercase tracking-[0.28em] text-cyan-200 sm:text-sm">
                    Latest Recruiter Signal
                  </p>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {[
                      ["Trust", "58/100"],
                      ["Pressure", "Medium"],
                      ["Trend", "Recovering"],
                      ["Focus", "Metrics"],
                    ].map(([label, value]) => (
                      <div key={label} className="min-w-0 rounded-2xl border border-white/10 bg-white/[0.04] p-5">
                        <p className="text-sm font-bold text-slate-400">{label}</p>
                        <p className="mt-2 break-words text-2xl font-black leading-tight">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section className="rounded-[30px] border border-white/10 bg-white/[0.03] p-6 lg:p-8">
              <p className="mb-5 text-xs font-black uppercase tracking-[0.28em] text-cyan-200 sm:text-sm">
                Your Job Journey
              </p>
              <h2 className="mb-7 text-3xl font-black sm:text-4xl">Progress snapshot</h2>

              <div className="space-y-4">
                {progress.map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] p-5"
                  >
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-400/10 text-emerald-300">
                      <CheckCircle2 className="h-5 w-5" />
                    </span>
                    <span className="text-lg font-black">{item.label}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <section className="grid gap-6 lg:grid-cols-3">
            {[
              {
                title: "Improve CV",
                description: "Clean, recruiter-safe CV improvement using the uploaded profile.",
                href: "/cv",
                icon: FileText,
              },
              {
                title: "Cover Letter",
                description: "Generate a tailored cover letter from the CV and target role.",
                href: "/cover-letter",
                icon: Mail,
              },
              {
                title: "Find Jobs",
                description: "Use the role and market context to prepare job-search direction.",
                href: "/jobs",
                icon: Search,
              },
            ].map((card) => {
              const CardIcon = card.icon;
              return (
                <Link
                  key={card.title}
                  href={card.href}
                  className="rounded-[26px] border border-white/10 bg-white/[0.035] p-6 transition hover:-translate-y-0.5 hover:bg-white/[0.06]"
                >
                  <CardIcon className="mb-5 h-6 w-6 text-cyan-200" />
                  <h3 className="text-xl font-black">{card.title}</h3>
                  <p className="mt-3 text-sm leading-6 text-slate-400">{card.description}</p>
                </Link>
              );
            })}
          </section>
        </section>
      </div>
    </main>
  );
}
