"use client";

import {
  extractResumeProfile,
  normalizeResumeText,
  type ResumeExperience,
  type ResumeProfile,
} from "@/lib/workzoResumeParser";

export type CvTemplate = "ats" | "modern" | "career_switcher";
export type ResumeMarket = "global" | "us" | "uk" | "germany" | "india" | "canada" | "australia" | "netherlands" | string;
export type ResumeStyle = "ats_clean" | "modern_professional" | "career_switcher" | "startup_modern" | "corporate";
export type MatchLevel = "strong" | "partial" | "stretch" | "unknown";

export type CvGenerationInput = {
  cvText?: string;
  resumeProfile?: ResumeProfile;
  jobDescription?: string;
  targetRole?: string;
  targetMarket?: ResumeMarket;
  template?: CvTemplate | ResumeStyle | string;
  companyName?: string;
};

type JdSignal = {
  targetRole: string;
  family: string;
  label: string;
  hardSkills: string[];
  tools: string[];
  requirements: string[];
  transferableNeeds: string[];
};

export type ResumeJson = {
  profile: ResumeProfile;
  basics: ResumeProfile["basics"];
  summary: string;
  skills: string[];
  groupedSkills: string[];
  experience: ResumeExperience[];
  projects: ResumeProfile["projects"];
  education: ResumeProfile["education"];
  languages: string[];
  strengths: string[];
  roleFit: {
    label: string;
    safeHeadline: string;
    highlights: string[];
    gaps: string[];
    keywords: string[];
    matchLevel: MatchLevel;
  };
  market: ResumeMarket;
  style: ResumeStyle;
};

const FAMILIES = [
  {
    family: "production_operations",
    label: "Production / Operations",
    terms: [
      "production",
      "production control",
      "production supervisor",
      "warehouse",
      "warehousing",
      "material handling",
      "logistics",
      "inventory",
      "shipping",
      "manufacturing",
      "5s",
      "continuous improvement",
      "safety",
      "quality",
      "delivery",
      "on-time delivery",
      "kpi",
      "supervisor",
      "material flow",
      "material planning",
    ],
    needs: [
      "manufacturing or process exposure",
      "cross-functional coordination",
      "documentation and reporting",
      "quality and delivery mindset",
      "continuous improvement awareness",
      "safety and KPI awareness",
      "team training or mentoring exposure",
    ],
  },
  {
    family: "data_analytics",
    label: "Data Analytics",
    terms: ["data", "analytics", "sql", "python", "dashboard", "reporting", "insights", "tableau", "power bi", "kpi", "a/b testing"],
    needs: ["analytical problem solving", "reporting and dashboards", "business insight communication", "data interpretation", "tool-based analysis"],
  },
  {
    family: "sales_business_development",
    label: "Sales / Business Development",
    terms: ["sales", "business development", "lead generation", "prospecting", "pipeline", "crm", "outreach", "revenue", "client", "buyer", "decision maker"],
    needs: ["client-facing communication", "customer need discovery", "relationship building", "product explanation", "pipeline or reporting mindset"],
  },
  {
    family: "technical_support",
    label: "Technical Support",
    terms: ["technical support", "it support", "service desk", "helpdesk", "troubleshooting", "ticket", "itil", "itsm", "support engineer", "application engineer"],
    needs: ["technical troubleshooting", "customer issue resolution", "escalation handling", "documentation", "service delivery"],
  },
  {
    family: "engineering_design",
    label: "Engineering / Design",
    terms: ["cad", "mechanical", "engineering", "product design", "prototype", "solidworks", "creo", "manufacturability", "technical drawings"],
    needs: ["engineering design", "technical documentation", "prototyping", "manufacturing collaboration", "problem solving"],
  },
  {
    family: "generic",
    label: "General Role",
    terms: [],
    needs: ["communication", "problem solving", "collaboration", "ownership"],
  },
];

const HARD_SKILLS = [
  "Python",
  "SQL",
  "Excel",
  "Tableau",
  "Power BI",
  "A/B Testing",
  "GCP",
  "AWS",
  "REST APIs",
  "ITIL",
  "ITSM",
  "Technical Support",
  "Troubleshooting",
  "CRM",
  "Lead Generation",
  "Prospecting",
  "5S",
  "Lean Manufacturing",
  "Continuous Improvement",
  "Safety",
  "Quality",
  "On-time Delivery",
  "Inventory",
  "Material Handling",
  "Logistics",
  "Warehouse Management",
  "Training",
  "Coaching",
  "CAD",
  "3D CAD",
  "CREO",
  "SolidWorks",
  "Catia V5",
  "Inventor",
  "Windchill",
  "CNC",
  "3D Printing",
  "Mechanical Design",
  "Product Design",
  "Prototyping",
  "Documentation",
  "Stakeholder Communication",
];

const TOOLS = [
  "Excel",
  "Microsoft Office",
  "Warehouse Management System",
  "WMS",
  "SAP",
  "Salesforce",
  "HubSpot",
  "Zoho",
  "Pipedrive",
  "SQL",
  "Python",
  "Tableau",
  "Power BI",
  "CREO",
  "SolidWorks",
  "Catia V5",
  "Inventor",
  "Windchill",
  "CNC",
  "3D Printing",
  "GCP",
  "AWS",
];

function clean(value = "") {
  return normalizeResumeText(value).replace(/\s+/g, " ").trim();
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function unique<T>(items: T[], key = (value: T) => String(value).toLowerCase()) {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of items) {
    const k = key(item).replace(/\s+/g, " ").trim().toLowerCase();
    if (!k || seen.has(k)) continue;
    seen.add(k);
    out.push(item);
  }
  return out;
}

function contains(source: string, term: string) {
  return new RegExp(escapeRegExp(term), "i").test(source);
}

function normalizeMarket(market?: ResumeMarket) {
  const value = String(market || "global").trim().toLowerCase();
  if (["de", "deutschland", "germany"].includes(value)) return "germany";
  if (["nl", "netherlands", "holland"].includes(value)) return "netherlands";
  if (["usa", "us", "united states"].includes(value)) return "us";
  if (["uk", "united kingdom", "england"].includes(value)) return "uk";
  if (["in", "india"].includes(value)) return "india";
  return value || "global";
}

function normalizeStyle(template?: CvGenerationInput["template"]): ResumeStyle {
  const value = String(template || "ats").trim().toLowerCase();
  if (value === "modern") return "modern_professional";
  if (value === "ats") return "ats_clean";
  if (value === "career_switcher") return "career_switcher";
  if (value === "startup") return "startup_modern";
  if (value === "corporate") return "corporate";
  if (["ats_clean", "modern_professional", "career_switcher", "startup_modern", "corporate"].includes(value)) return value as ResumeStyle;
  return "ats_clean";
}

function titleFromJd(jobDescription = "", targetRole = "") {
  const explicit = clean(targetRole);
  if (explicit && !/^target role$/i.test(explicit)) return explicit;
  const firstLines = jobDescription.split("\n").map(clean).filter(Boolean).slice(0, 10);
  return firstLines.find((line) => /manager|engineer|analyst|supervisor|specialist|developer|designer|consultant|coordinator|associate|lead|support|scientist/i.test(line)) || "Target Role";
}

function analyzeJd(jobDescription = "", targetRole = ""): JdSignal {
  const source = `${targetRole}\n${jobDescription}`.toLowerCase();
  let best = FAMILIES[FAMILIES.length - 1];
  let bestScore = -1;

  for (const family of FAMILIES) {
    const score = family.terms.reduce((total, term) => total + (contains(source, term) ? 1 : 0), 0);
    if (score > bestScore) {
      bestScore = score;
      best = family;
    }
  }

  const hardSkills = HARD_SKILLS.filter((skill) => contains(source, skill));
  const tools = TOOLS.filter((tool) => contains(source, tool));
  const requirements = jobDescription
    .split("\n")
    .map((line) => clean(line.replace(/^[-•*]\s*/, "")))
    .filter((line) => /manage|ensure|maintain|lead|coach|train|support|prepare|analyze|coordinate|develop|improve|report|ship|stock|unload|resolve|design|present|build|create/i.test(line))
    .slice(0, 12);

  return {
    targetRole: titleFromJd(jobDescription, targetRole),
    family: bestScore > 0 ? best.family : "generic",
    label: bestScore > 0 ? best.label : "General Role",
    hardSkills,
    tools,
    requirements,
    transferableNeeds: best.needs,
  };
}

function evidenceSource(profile: ResumeProfile) {
  return [
    profile.summary,
    profile.skills.join(" "),
    profile.strengths.join(" "),
    ...profile.experience.flatMap((job) => [job.title, job.company, job.location, ...job.bullets]),
    ...profile.projects.flatMap((project) => [project.name, ...project.bullets]),
    ...profile.education.flatMap((edu) => [edu.degree, edu.institution]),
  ].join(" ");
}

function cleanVisibleHeadline(value = "") {
  const headline = clean(value)
    .replace(/\bRole-Relevant Professional\b/gi, "Professional")
    .replace(/\s+with\s+manufacturing.*$/i, "")
    .replace(/\s+with\s+analytics.*$/i, "")
    .replace(/\s+with\s+technical.*$/i, "")
    .replace(/\s+with\s+client.*$/i, "")
    .replace(/\s+with\s+transferable.*$/i, "")
    .trim();

  if (!headline || /role-relevant|transferable|coordination experience|mindset|evidence|opportunities|role fit|process exposure|stakeholder/i.test(headline)) {
    return "Professional";
  }

  return headline;
}

function realisticTransitionHeadline(current: string, family: string) {
  const base = cleanVisibleHeadline(current);

  if (family === "production_operations") {
    if (/product design|mechanical|cad|manufacturing|engineering/i.test(base)) return "Product Design Engineer | Manufacturing Operations";
    return "Manufacturing Operations Professional";
  }

  if (family === "data_analytics") {
    if (/support|it|technical/i.test(base)) return "IT Support Specialist | Data Analyst";
    return base === "Professional" ? "Data Analyst" : base;
  }

  if (family === "technical_support") return base === "Professional" ? "Technical Support Professional" : base;
  if (family === "sales_business_development") return base === "Professional" ? "Business Development Professional" : base;

  return base;
}

function safeHeadline(profile: ResumeProfile, jd: JdSignal) {
  const current = cleanVisibleHeadline(profile.basics.headline || "Professional");
  if (jd.family === "generic") return current;
  return realisticTransitionHeadline(current, jd.family);
}

function buildRoleFit(profile: ResumeProfile, jd: JdSignal) {
  const evidence = evidenceSource(profile);
  const highlights: string[] = [];

  jd.transferableNeeds.forEach((need) => {
    const terms = need.split(/\s+|\/|-/).filter((word) => word.length > 4);
    if (terms.some((term) => contains(evidence, term))) highlights.push(need);
  });

  if (/customer|client|support|stakeholder|communication|training/i.test(evidence)) highlights.push("stakeholder and customer-facing communication");
  if (/\d+%|\d+\+|reduced|improved|increased|resolved|cutting|boosting|dashboard|report/i.test(evidence)) highlights.push("measurable outcomes and reporting mindset");
  if (/python|sql|excel|tableau|power bi|dashboard|data|analysis/i.test(evidence)) highlights.push("analytical and tool-based problem solving");
  if (/manufactur|product|design|cad|technical drawing|prototype|mechanical|process/i.test(evidence)) highlights.push("technical/product process experience");
  if (/manufactur|quality|process|product|engineering change|cross-functional|material|logistics|warehouse|safety/i.test(evidence)) highlights.push("production, quality, and process coordination exposure");
  if (/technical drawing|documentation|report|excel|microsoft office|windchill|plm/i.test(evidence)) highlights.push("documentation and system-based reporting mindset");

  const keywords = unique([...jd.hardSkills, ...jd.tools, ...jd.transferableNeeds]).slice(0, 14);
  const gaps = keywords.filter((keyword) => !contains(evidence, keyword.split(" ")[0])).slice(0, 5);

  const matchLevel: MatchLevel =
    highlights.length >= 5 ? "strong" : highlights.length >= 3 ? "partial" : highlights.length >= 1 ? "stretch" : "unknown";

  return {
    label: jd.targetRole,
    safeHeadline: safeHeadline(profile, jd),
    highlights: unique(highlights).slice(0, 6),
    gaps,
    keywords,
    matchLevel,
  };
}

function cleanSkillForDisplay(value = "") {
  return clean(value)
    .replace(/\bWÜRzburg\b/gi, "")
    .replace(/\bWürzburg\b/gi, "")
    .replace(/\bGermany\b/gi, "")
    .replace(/\bEducation\b/gi, "")
    .replace(/\bLanguages\b/gi, "")
    .replace(/\bQuality Education Languages\b/gi, "Quality")
    .replace(/\bInventor 3d Printing:\s*Fff\b/gi, "Inventor")
    .replace(/\b3d Printing\b/gi, "3D Printing")
    .replace(/\bFff\b/g, "FFF")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanSkillsForDisplay(items: string[]) {
  return unique(
    items
      .map(cleanSkillForDisplay)
      .filter(Boolean)
      .filter((item) => !/^(education|languages|contact|profile|summary|work experience|tools)$/i.test(item))
      .filter((item) => !/\b(würzburg|germany|linkedin|outlook|gmail|@|\+\d)\b/i.test(item)),
  );
}

function groupedSkillLines(skills: string[]) {
  const cleanSkills = cleanSkillsForDisplay(skills);
  const technical = cleanSkills.filter((s) => /python|sql|api|cad|creo|solidworks|catia|inventor|windchill|cnc|3d printing|plm|mechanical|product design|prototype|tensorflow|sklearn|gcp|aws/i.test(s));
  const operations = cleanSkills.filter((s) => /lean|5s|warehouse|inventory|material|logistics|safety|quality|delivery|training|documentation|process|project|agile|scrum|manufacturing/i.test(s));
  const reporting = cleanSkills.filter((s) => /excel|report|dashboard|tableau|power bi|matplotlib|seaborn|pandas|analytics|visualization|kpi/i.test(s));
  const customer = cleanSkills.filter((s) => /communication|stakeholder|customer|client|relationship|support|troubleshooting|itil|itsm/i.test(s));

  return [
    technical.length ? `Technical: ${technical.join(", ")}` : "",
    reporting.length ? `Data & Reporting: ${reporting.join(", ")}` : "",
    operations.length ? `Operations: ${operations.join(", ")}` : "",
    customer.length ? `Communication & Support: ${customer.join(", ")}` : "",
  ].filter(Boolean);
}

function profileFromInput(input: CvGenerationInput) {
  return input.resumeProfile || extractResumeProfile(input.cvText || "");
}


function compactSentence(value = "", max = 420) {
  const cleaned = clean(value)
    .replace(/\s+/g, " ")
    .replace(/\bThis background is relevant to.*$/i, "")
    .replace(/\bThe experience shows practical strengths in.*$/i, "")
    .trim();

  if (cleaned.length <= max) return cleaned;
  const sentence = cleaned
    .split(/(?<=[.!?])\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .join(" ");

  return sentence.length > 60 ? sentence : `${cleaned.slice(0, max).replace(/\s+\S*$/, "")}.`;
}


function enrichExperienceBullet(bullet = "", jobTitle = "", family = "") {
  const source = clean(bullet)
    .replace(/\bimprove\.\s+product manufacturability\.?/gi, "improve product manufacturability")
    .replace(/\busing\.\s+CAD and supported mechanical integration\.?/gi, "using CAD and supported mechanical integration")
    .replace(/\band\.\s+CAD-based prototyping\.?/gi, "and CAD-based prototyping")
    .replace(/\bAssisted in developing ([^.]+) and\.?$/i, "Assisted in developing $1 and CAD-based prototypes")
    .replace(/\bParticipated in the design and construction of float\.?$/i, "Participated in the design and construction of floating test systems")
    .replace(/\bCollaborate with cross-functional teams to improve\.?$/i, "Collaborated with cross-functional teams to improve product manufacturability")
    .replace(/\bEngineering\.?$/i, "")
    .replace(/\s+/g, " ")
    .trim();

  if (!source || source.length < 18) return "";

  // Truth-preserving enrichment: only expands incomplete extracted phrases into professional wording.
  if (/creating detailed cad models and technical drawings/i.test(source)) {
    return "Created detailed CAD models and technical drawings to support engineering, manufacturing, and product design requirements.";
  }

  if (/engineering change management/i.test(source)) {
    return "Supported product design updates and engineering change management processes across cross-functional teams.";
  }

  if (/cross-functional teams.*manufacturability/i.test(source)) {
    return "Collaborated with cross-functional engineering teams to improve product manufacturability and production readiness.";
  }

  if (/sanding and polishing machines/i.test(source)) {
    return "Designed and prototyped sanding and polishing machines for industrial production use.";
  }

  if (/mobile sanding stations/i.test(source)) {
    return "Developed and installed mobile sanding stations to support on-site operational requirements.";
  }

  if (/robot units.*cad.*mechanical integration/i.test(source)) {
    return "Engineered CAD-based body components for robot units and supported mechanical integration activities.";
  }

  if (/floating test systems|float/i.test(source)) {
    return "Participated in the design and construction of floating test systems for space systems engineering projects.";
  }

  if (/satellite sphere test beds/i.test(source)) {
    return "Assisted in developing satellite sphere test beds and CAD-based prototypes for research and testing activities.";
  }

  if (/fabricated models.*cnc|3d printing/i.test(source)) {
    return "Fabricated physical models using CNC machining and 3D printing technologies.";
  }

  return source.endsWith(".") ? source : `${source}.`;
}

function relevantBulletScore(bullet = "", family = "") {
  let score = 0;
  const text = bullet.toLowerCase();

  if (/improved|created|designed|developed|engineered|supported|collaborated|fabricated|managed|led|trained|optimized/.test(text)) score += 3;
  if (/cad|engineering|manufactur|production|quality|process|technical|prototype|design|documentation|change|cross-functional/.test(text)) score += 3;
  if (family === "production_operations" && /manufactur|production|quality|process|cross-functional|technical|cad|design|prototype|engineering/.test(text)) score += 3;
  if (/\d|%|kpi|time|cost|quality|safety/.test(text)) score += 1;
  if (text.length < 28) score -= 4;
  if (/^engineering\.?$|^and\.?$|^using\.?$/.test(text)) score -= 10;

  return score;
}


function onePageLimitExperience(items: ResumeExperience[], family: string) {
  const maxRoles = 3;

  return items.slice(0, maxRoles).map((job, index) => {
    const maxBullets = index === 0 ? 4 : 3;

    const enriched = unique(
      job.bullets
        .flatMap((bullet) =>
          clean(bullet)
            .replace(/\s+(Responsible for|Support|Collaborate|Designed|Developed|Engineered|Participated|Assisted|Fabricated|Automated|Built|Delivered|Conducted|Managed|Resolved|Created|Maintained|Led|Trained|Prepared|Analyzed|Analysed|Implemented|Optimized|Monitored)\b/g, "|||$1")
            .split("|||"),
        )
        .map((bullet) => enrichExperienceBullet(bullet, job.title, family))
        .filter(Boolean),
    );

    const bullets = enriched
      .sort((a, b) => relevantBulletScore(b, family) - relevantBulletScore(a, family))
      .slice(0, maxBullets);

    return { ...job, bullets };
  });
}

function onePageLimitEducation(items: ResumeJson["education"]) {
  return items.slice(0, 3).map((item) => ({
    ...item,
    degree: clean(item.degree)
      .replace(/\bMaster'S\b/g, "Master's")
      .replace(/\bBachelor'S\b/g, "Bachelor's")
      .replace(/\s+/g, " "),
    institution: clean(item.institution)
      .replace(/\s*\|\s*/g, " · ")
      .replace(/\bMaster'S\b/g, "Master's")
      .replace(/\bBachelor'S\b/g, "Bachelor's"),
  }));
}

function onePageLimitProjects(items: ResumeJson["projects"]) {
  return items.slice(0, 2).map((project) => ({
    ...project,
    bullets: project.bullets.slice(0, 2),
  }));
}

function onePageSkills(skills: string[], family: string) {
  const preferred =
    family === "production_operations"
      ? [
          "CAD",
          "3D CAD",
          "CREO",
          "SolidWorks",
          "Catia V5",
          "Inventor",
          "Windchill",
          "Mechanical Design",
          "Product Design",
          "Prototyping",
          "Manufacturing Support",
          "Quality",
          "Safety",
          "5S",
          "Lean Manufacturing",
          "Material Flow",
          "KPI Reporting",
          "Excel",
          "Microsoft Office",
        ]
      : skills;

  const ordered = [
    ...preferred.filter((skill) => skills.some((item) => item.toLowerCase() === skill.toLowerCase())),
    ...skills,
  ];

  return cleanSkillsForDisplay(unique(ordered)).slice(0, 22);
}

function onePageSummary(profile: ResumeProfile, roleFit: ResumeJson["roleFit"], family: string, hasJd: boolean) {
  const base = compactSentence(profile.summary, 330);

  if (!hasJd || family === "generic") return base;

  if (family === "production_operations") {
    return compactSentence(
      `${base} Brings experience in manufacturing-focused design support, technical documentation, product manufacturability, and cross-functional engineering collaboration.`,
      450,
    );
  }

  const strengths = roleFit.highlights
    .filter((item) => !/mindset|opportunities|evidence|process exposure/i.test(item))
    .slice(0, 2)
    .join(" and ");

  if (!strengths) return base;

  return compactSentence(`${base} Brings practical strengths in ${strengths}.`, 430);
}



function adaptiveExperienceForPage(profile: ResumeProfile, family: string) {
  const source = onePageLimitExperience(profile.experience, family);

  // If the parsed CV has enough real experience detail, allow more bullets to fill the page.
  // This is global: it expands only existing CV-based experience, not fake JD content.
  const hasEnoughSpace = source.length <= 3;
  const totalBullets = source.reduce((sum, job) => sum + job.bullets.length, 0);

  if (!hasEnoughSpace || totalBullets >= 9) return source;

  return profile.experience.slice(0, 3).map((job, index) => {
    const maxBullets = index === 0 ? 5 : 4;

    const enriched = unique(
      job.bullets
        .flatMap((bullet) =>
          clean(bullet)
            .replace(/\s+(Responsible for|Support|Collaborate|Designed|Developed|Engineered|Participated|Assisted|Fabricated|Automated|Built|Delivered|Conducted|Managed|Resolved|Created|Maintained|Led|Trained|Prepared|Analyzed|Analysed|Implemented|Optimized|Monitored)\b/g, "|||$1")
            .split("|||"),
        )
        .map((bullet) => enrichExperienceBullet(bullet, job.title, family))
        .filter(Boolean),
    )
      .sort((a, b) => relevantBulletScore(b, family) - relevantBulletScore(a, family))
      .slice(0, maxBullets);

    return {
      ...job,
      bullets: enriched,
    };
  });
}

function adaptiveProjectsForPage(profile: ResumeProfile, experience: ResumeExperience[]) {
  const bulletCount = experience.reduce((sum, job) => sum + job.bullets.length, 0);

  if (bulletCount < 8) {
    return profile.projects.slice(0, 3).map((project) => ({
      ...project,
      bullets: project.bullets.slice(0, 3),
    }));
  }

  return onePageLimitProjects(profile.projects);
}

function adaptiveSkillsForPage(skills: string[], experience: ResumeExperience[]) {
  const bulletCount = experience.reduce((sum, job) => sum + job.bullets.length, 0);
  const limit = bulletCount < 8 ? 28 : 22;
  return cleanSkillsForDisplay(skills).slice(0, limit);
}


export function buildResumeJson(input: CvGenerationInput): ResumeJson {
  const profile = profileFromInput(input);
  const jd = analyzeJd(input.jobDescription || "", input.targetRole || "");
  const roleFit = buildRoleFit(profile, jd);
  const roleSkills =
    jd.family === "production_operations"
      ? ["Manufacturing Support", "Quality", "Safety", "On-time Delivery", "Continuous Improvement", "Material Flow", "KPI Reporting", "Training"]
      : [];

  const jdRelevantSkills = jd.hardSkills.filter((skill) =>
    profile.skills.some((existing) => existing.toLowerCase().includes(skill.toLowerCase()) || skill.toLowerCase().includes(existing.toLowerCase())),
  );
  const baseSkills = unique([...profile.skills, ...jdRelevantSkills, ...roleSkills]);
  const experience = adaptiveExperienceForPage(profile, jd.family);
  const projects = adaptiveProjectsForPage(profile, experience);
  const education = onePageLimitEducation(profile.education);
  const skills = adaptiveSkillsForPage(baseSkills, experience);
  const summary = onePageSummary(profile, roleFit, jd.family, Boolean(input.jobDescription?.trim()));

  return {
    profile,
    basics: {
      ...profile.basics,
      headline: roleFit.safeHeadline,
    },
    summary,
    skills,
    groupedSkills: groupedSkillLines(skills).slice(0, 4),
    experience,
    projects,
    education,
    languages: unique(profile.languages, (item) => item.split(" - ")[0]).slice(0, 3),
    strengths: profile.strengths.slice(0, 6),
    roleFit,
    market: normalizeMarket(input.targetMarket),
    style: normalizeStyle(input.template),
  };
}

function addSection(out: string[], title: string, lines: string[]) {
  const valid = lines.map(clean).filter(Boolean);
  if (!valid.length) return;
  out.push("", title, ...valid);
}

export function buildAtsCv(input: CvGenerationInput) {
  const data = buildResumeJson(input);
  const out: string[] = [];

  out.push(data.profile.basics.name);
  out.push(data.basics.headline);

  const contact = [data.profile.basics.phone, data.profile.basics.email, data.profile.basics.location, data.profile.basics.linkedin].filter(Boolean).join(" | ");
  if (contact) out.push(contact);

  addSection(out, "PROFESSIONAL SUMMARY", [data.summary]);
  addSection(out, "CORE SKILLS", data.groupedSkills);

  if (data.experience.length) {
    out.push("", "PROFESSIONAL EXPERIENCE");
    data.experience.forEach((job) => {
      out.push(`${job.title}${job.company ? ` | ${job.company}` : ""}${job.location ? ` | ${job.location}` : ""}${job.dates ? ` | ${job.dates}` : ""}`);
      job.bullets.forEach((bullet) => out.push(`- ${bullet}`));
    });
  }

  if (data.projects.length) {
    out.push("", "PROJECTS");
    data.projects.forEach((project) => {
      out.push(project.name);
      project.bullets.forEach((bullet) => out.push(`- ${bullet}`));
    });
  }

  if (data.education.length) {
    out.push("", "EDUCATION");
    data.education.forEach((item) => out.push(`${item.degree}${item.institution ? ` | ${item.institution}` : ""}${item.dates ? ` | ${item.dates}` : ""}`));
  }

  if (data.languages.length) addSection(out, "LANGUAGES", data.languages);
  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

export function generateImprovedCv(input: CvGenerationInput) {
  return buildAtsCv(input);
}

export function buildCoverLetter(input: CvGenerationInput) {
  const data = buildResumeJson(input);
  const role = data.roleFit.label || input.targetRole || "the role";
  const company = clean(input.companyName || "your company");
  const evidence = data.roleFit.highlights.slice(0, 3).join(", ") || "relevant transferable experience";

  return [
    "Dear Hiring Team,",
    "",
    `I am excited to apply for the ${role} position at ${company}. My background as ${data.profile.basics.headline} gives me relevant experience in ${evidence}.`,
    "",
    "I would welcome the opportunity to discuss how my experience, learning mindset, and practical problem-solving approach can support your team.",
    "",
    "Kind regards,",
    data.profile.basics.name,
  ].join("\n");
}

export function generateCoverLetter(input: CvGenerationInput) {
  return buildCoverLetter(input);
}

export function buildJobStrategy(input: CvGenerationInput) {
  const data = buildResumeJson(input);
  return {
    role: data.roleFit.label,
    market: data.market,
    keywords: data.roleFit.keywords,
    platforms:
      data.market === "germany"
        ? ["LinkedIn", "StepStone", "Indeed", "Xing", "Company career pages"]
        : data.market === "netherlands"
          ? ["LinkedIn", "Indeed", "Glassdoor", "Company career pages"]
          : ["LinkedIn", "Indeed", "Glassdoor", "Google Jobs", "Company career pages"],
    plan: [
      `Search for ${data.roleFit.label} and adjacent roles.`,
      "Prioritize roles where existing experience matches the core responsibilities.",
      "Use role-fit highlights in the summary and top experience bullets.",
      "Avoid overclaiming direct experience where the resume does not show it.",
      "Track applications and follow up after 5-7 days.",
    ],
    suggestedTitles: unique([data.roleFit.label, data.profile.basics.headline, `${data.roleFit.label} Coordinator`, `${data.roleFit.label} Associate`]).slice(0, 6),
  };
}

export function generateJobSearchPlan(input: CvGenerationInput) {
  return buildJobStrategy(input);
}

function escapeHtml(value = "") {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function renderList(items: string[]) {
  return items.map((item) => `<li>${escapeHtml(item.replace(/^-\s*/, ""))}</li>`).join("");
}

function renderExperience(items: ResumeExperience[], compact = false) {
  return items
    .map(
      (job) => `
    <section class="item">
      <div class="item-head">
        <div><h3>${escapeHtml(job.title)}</h3><p>${escapeHtml([job.company, job.location].filter(Boolean).join(" · "))}</p></div>
        <span>${escapeHtml(job.dates)}</span>
      </div>
      <ul>${renderList((compact ? job.bullets.slice(0, 4) : job.bullets).filter(Boolean))}</ul>
    </section>`,
    )
    .join("");
}

function renderAts(data: ResumeJson) {
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${escapeHtml(data.profile.basics.name)} CV</title>
  <style>*{box-sizing:border-box}body{margin:0;background:#f3f4f6;color:#111827;font-family:Arial,Helvetica,sans-serif;line-height:1.45}.page{width:210mm;min-height:297mm;margin:0 auto;background:#fff;padding:14mm 15mm;box-shadow:0 20px 50px rgba(15,23,42,.12)}header{text-align:center;border-bottom:2px solid #111827;padding-bottom:12px;margin-bottom:16px}h1{margin:0;font-size:22px;text-transform:uppercase;letter-spacing:.02em}.headline{margin-top:6px;font-size:13px;font-weight:700}.contact{margin-top:8px;color:#4b5563;font-size:10.5px}h2{margin:12px 0 5px;border-bottom:1px solid #d1d5db;padding-bottom:4px;font-size:11px;letter-spacing:.12em;text-transform:uppercase}p,li{font-size:10.4px}.item{margin-top:12px;break-inside:avoid}.item-head{display:flex;justify-content:space-between;gap:16px}.item-head p{margin:2px 0 0;color:#4b5563;font-size:10.7px}h3{margin:0;font-size:11.2px}ul{margin:4px 0 0;padding-left:16px}li{margin-bottom:3px}@media print{body{background:#fff}.page{box-shadow:none;margin:0;page-break-after:avoid} @page{size:A4;margin:0}}</style></head><body><div class="page">
    <header><h1>${escapeHtml(data.profile.basics.name)}</h1><div class="headline">${escapeHtml(data.basics.headline)}</div><div class="contact">${escapeHtml([data.profile.basics.phone, data.profile.basics.email, data.profile.basics.location, data.profile.basics.linkedin].filter(Boolean).join(" · "))}</div></header>
    <section><h2>Professional Summary</h2><p>${escapeHtml(data.summary)}</p></section>
    <section><h2>Core Skills</h2>${data.groupedSkills.map((line) => `<p>${escapeHtml(line)}</p>`).join("")}</section>
    ${data.experience.length ? `<section><h2>Professional Experience</h2>${renderExperience(data.experience)}</section>` : ""}
    ${data.projects.length ? `<section><h2>Projects</h2>${data.projects.map((p) => `<div class="item"><h3>${escapeHtml(p.name)}</h3><ul>${renderList(p.bullets)}</ul></div>`).join("")}</section>` : ""}
    ${data.education.length ? `<section><h2>Education</h2><ul>${renderList(data.education.map((e) => `${e.degree}${e.institution ? ` | ${e.institution}` : ""}${e.dates ? ` | ${e.dates}` : ""}`))}</ul></section>` : ""}
    ${data.languages.length ? `<section><h2>Languages</h2><p>${escapeHtml(data.languages.join(" | "))}</p></section>` : ""}
  </div></body></html>`;
}

function renderModern(data: ResumeJson) {
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${escapeHtml(data.profile.basics.name)} CV</title>
  <style>*{box-sizing:border-box}body{margin:0;background:#e5e7eb;color:#111827;font-family:Inter,Arial,sans-serif;line-height:1.45}.page{width:210mm;min-height:297mm;margin:0 auto;background:#fff;display:grid;grid-template-columns:62mm 1fr;box-shadow:0 20px 50px rgba(15,23,42,.14)}aside{background:#f7faff;border-right:1px solid #dbe4ee;padding:24px 17px}main{padding:26px 24px}.bar{width:42px;height:4px;background:#2563eb;border-radius:999px;margin-bottom:18px}h1{margin:0;font-size:23px;line-height:1.05;letter-spacing:-.9px}.headline{margin:10px 0 16px;color:#1e3a8a;font-size:14px;font-weight:800}.contact{display:grid;gap:7px;color:#5b6472;font-size:11px;overflow-wrap:anywhere}h2{margin:16px 0 7px;color:#1e3a8a;font-size:11px;letter-spacing:.12em;text-transform:uppercase;border-bottom:1px solid #dbe4ee;padding-bottom:7px}.summary{padding:10px 12px;border-left:4px solid #2563eb;background:#f8fbff;border-radius:14px;font-size:13px}.chip{display:inline-block;margin:3px 4px 3px 0;padding:5px 8px;border:1px solid #dbe4ee;border-radius:999px;font-size:10px;font-weight:700}.item{margin-top:12px;break-inside:avoid}.item-head{display:flex;justify-content:space-between;gap:18px}.item-head p{margin:2px 0 0;color:#5b6472;font-size:11px}h3{margin:0;font-size:11.4px}li{font-size:10.4px;margin-bottom:3px}@media print{body{background:#fff}.page{box-shadow:none;margin:0;page-break-after:avoid} @page{size:A4;margin:0}}</style></head><body><div class="page">
    <aside><div class="bar"></div><h1>${escapeHtml(data.profile.basics.name)}</h1><div class="headline">${escapeHtml(data.basics.headline)}</div><div class="contact">${[data.profile.basics.phone, data.profile.basics.email, data.profile.basics.location, data.profile.basics.linkedin].filter(Boolean).map((v) => `<div>${escapeHtml(v)}</div>`).join("")}</div>
      <h2>Skills</h2><div>${cleanSkillsForDisplay(data.skills).slice(0, 24).map((s) => `<span class="chip">${escapeHtml(s)}</span>`).join("")}</div>
      ${data.languages.length ? `<h2>Languages</h2><p>${escapeHtml(data.languages.join(" | "))}</p>` : ""}
      ${data.strengths.length ? `<h2>Strengths</h2><ul>${renderList(data.strengths.slice(0, 6))}</ul>` : ""}
    </aside>
    <main><section><h2>Professional Summary</h2><p class="summary">${escapeHtml(data.summary)}</p></section>
    ${data.experience.length ? `<section><h2>Professional Experience</h2>${renderExperience(data.experience)}</section>` : ""}
    ${data.projects.length ? `<section><h2>Projects</h2>${data.projects.map((p) => `<div class="item"><h3>${escapeHtml(p.name)}</h3><ul>${renderList(p.bullets.slice(0, 3))}</ul></div>`).join("")}</section>` : ""}
    ${data.education.length ? `<section><h2>Education</h2><ul>${renderList(data.education.map((e) => `${e.degree}${e.institution ? ` | ${e.institution}` : ""}${e.dates ? ` | ${e.dates}` : ""}`))}</ul></section>` : ""}
    </main></div></body></html>`;
}

function renderCareerSwitcher(data: ResumeJson) {
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${escapeHtml(data.profile.basics.name)} CV</title>
  <style>*{box-sizing:border-box}body{margin:0;background:#e2e8f0;color:#172033;font-family:Inter,Arial,sans-serif;line-height:1.48}.page{width:210mm;min-height:297mm;margin:0 auto;background:#fff;padding:16px 22px 22px;box-shadow:0 20px 50px rgba(15,23,42,.14)}header{display:grid;grid-template-columns:1fr 62mm;gap:14px;padding:14px;border-radius:26px;background:linear-gradient(135deg,#ecfeff,#fff 55%,#fff7ed);border:1px solid #d7e6ea;margin-bottom:22px}.badge{display:inline-block;margin-bottom:10px;padding:6px 10px;border-radius:999px;background:#cffafe;color:#155e75;font-size:10px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}h1{margin:0;font-size:23px;line-height:1.05}.headline{margin-top:8px;color:#155e75;font-size:14px;font-weight:800}.summary{font-size:12.5px;color:#27364a}.contact{display:grid;gap:7px;color:#667085;font-size:10.8px;overflow-wrap:anywhere}.grid{display:grid;grid-template-columns:1fr 58mm;gap:14px}h2{margin:0 0 11px;color:#155e75;font-size:11px;font-weight:850;letter-spacing:.13em;text-transform:uppercase;border-bottom:1px solid #d7e6ea;padding-bottom:7px}.section{margin-top:16px}.item{margin-top:12px;break-inside:avoid}.item-head{display:flex;justify-content:space-between;gap:14px}h3{margin:0;font-size:11.4px}.item-head p{margin:2px 0 0;color:#667085;font-size:11px}li{font-size:10px;margin-bottom:2px}.side{padding:12px;border-radius:20px;background:#f8fafc;border:1px solid #e2e8f0;margin-bottom:20px}.chip{display:inline-block;margin:3px;padding:5px 8px;border-radius:999px;background:#fff;border:1px solid #dbe4ee;font-size:10px;font-weight:700}@media print{body{background:#fff}.page{box-shadow:none;margin:0;page-break-after:avoid} @page{size:A4;margin:0}}</style></head><body><div class="page">
    <header><div><span class="badge">Professional Profile</span><h1>${escapeHtml(data.profile.basics.name)}</h1><div class="headline">${escapeHtml(data.basics.headline)}</div><p class="summary">${escapeHtml(data.summary)}</p></div><div class="contact">${[data.profile.basics.phone, data.profile.basics.email, data.profile.basics.location, data.profile.basics.linkedin].filter(Boolean).map((v) => `<div>${escapeHtml(v)}</div>`).join("")}</div></header>
    <div class="grid"><main>${data.projects.length ? `<section class="section"><h2>Projects</h2>${data.projects.map((p) => `<div class="item"><h3>${escapeHtml(p.name)}</h3><ul>${renderList(p.bullets.slice(0, 3))}</ul></div>`).join("")}</section>` : ""}${data.experience.length ? `<section class="section"><h2>Professional Experience</h2>${renderExperience(data.experience, true)}</section>` : ""}</main><aside><section class="side"><h2>Skills</h2>${cleanSkillsForDisplay(data.skills).slice(0, 22).map((s) => `<span class="chip">${escapeHtml(s)}</span>`).join("")}</section>${data.education.length ? `<section class="side"><h2>Education</h2><ul>${renderList(data.education.map((e) => `${e.degree}${e.institution ? ` | ${e.institution}` : ""}${e.dates ? ` | ${e.dates}` : ""}`))}</ul></section>` : ""}${data.languages.length ? `<section class="side"><h2>Languages</h2><p>${escapeHtml(data.languages.join(" | "))}</p></section>` : ""}</aside></div>
  </div></body></html>`;
}

export function generateResumeHtml(input: CvGenerationInput) {
  const data = buildResumeJson(input);
  if (data.style === "career_switcher") return renderCareerSwitcher(data);
  if (data.style === "ats_clean") return renderAts(data);
  return renderModern(data);
}

export function downloadHtmlFile(filename: string, html: string) {
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.endsWith(".html") ? filename : `${filename}.html`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function printResumeHtml(html: string) {
  const win = window.open("", "_blank", "width=900,height=1000");
  if (!win) return;
  win.document.open();
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 350);
}

export function createSimplePdfBlob(title: string, content?: string) {
  return new Blob([content || title || ""], { type: "text/plain;charset=utf-8" });
}

export function downloadTextPdf(filename: string, title: string, content: string) {
  const blob = createSimplePdfBlob(title, content);
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.replace(/\.pdf$/i, ".txt");
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function downloadBlob(filename: string, bytes: Uint8Array | string, mime: string) {
  const blob = typeof bytes === "string" ? new Blob([bytes], { type: mime }) : new Blob([new Uint8Array(bytes)], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function getCvTemplateNames() {
  return [
    { id: "ats", name: "ATS Clean" },
    { id: "modern", name: "Modern Professional" },
    { id: "career_switcher", name: "Career Switcher" },
  ] as const;
}
