"use client";

/**
 * WorkZo AI — CV Parser v3
 * Replace: lib/workzoResumeParser.ts
 *
 * Core fix:
 * - Experience extraction uses RAW LINE WINDOWS, not merged text.
 * - Company/title rows cannot swallow work bullets.
 * - Projects, skills, education and profile content are classified separately.
 * - Designed for mixed-order sidebar CVs and normal single-column CVs.
 */

export type ResumeSectionKind =
  | "summary"
  | "experience"
  | "education"
  | "skills"
  | "projects"
  | "languages"
  | "certifications"
  | "contact"
  | "unknown";

export type ResumeExperience = {
  title: string;
  company: string;
  location: string;
  dates: string;
  bullets: string[];
};

export type ResumeEducation = {
  degree: string;
  institution: string;
  location: string;
  dates: string;
};

export type ResumeProject = {
  name: string;
  bullets: string[];
};

export type ResumeProfile = {
  rawText: string;
  basics: {
    name: string;
    headline: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
  };
  summary: string;
  experience: ResumeExperience[];
  education: ResumeEducation[];
  skills: string[];
  projects: ResumeProject[];
  languages: string[];
  certifications: string[];
  strengths: string[];
  warnings: string[];
  previewText: string;
};

type SectionMap = Record<ResumeSectionKind, string[]>;

const KNOWN_SKILLS = [
  "Python",
  "SQL",
  "Excel",
  "Microsoft Excel",
  "Microsoft Word",
  "Microsoft Office",
  "Tableau",
  "Power BI",
  "Matplotlib",
  "Seaborn",
  "Pandas",
  "Sklearn",
  "TensorFlow",
  "NLP",
  "TextBlob",
  "Machine Learning",
  "Generative AI",
  "LangChain",
  "RAG",
  "REST APIs",
  "API",
  "API Integration",
  "Web Scraping",
  "MySQL",
  "GCP",
  "AWS",
  "Zoho",
  "Technical Support",
  "Troubleshooting",
  "ITIL",
  "ITSM",
  "Service Delivery",
  "Requirements Analysis",
  "Knowledge Base",
  "Customer Issue Resolution",
  "Stakeholder Communication",
  "Escalation Handling",
  "Documentation",
  "Reporting",
  "Dashboards",
  "Process Improvement",
  "Project Management",
  "Agile",
  "Training",
  "CAD",
  "3D CAD",
  "CREO",
  "SolidWorks",
  "Catia V5",
  "Inventor",
  "Windchill",
  "CNC",
  "3D Printing",
  "Mechanical Design",
  "Product Design",
  "Prototyping",
];

const COMPANY_RE =
  /\b(zoho|css corp|belkin|linksys|manageengine|servicedesk|tesla|cummins|visomax|gmbh|ltd|llc|inc|corp|corporation|company|technologies|technology|solutions|systems|group|pvt|private limited|limited|ag|se|bv|plc)\b/i;

const EDUCATION_ORG_RE =
  /\b(university|college|school|institute|academy|coding school|arts and science|wbs|srm)\b/i;

const DEGREE_RE =
  /\b(master|bachelor|degree|phd|mba|b\.sc|m\.sc|bsc|msc|bootcamp|diploma|certificate|certification|science|arts|engineering|technology|computer science|data science)\b/i;

const ROLE_RE =
  /\b(junior data analyst|junior data scientist|data analyst|data scientist|it support specialist|technical support engineer|application engineer|support engineer|support specialist|product specialist|product design engineer|cad designer|engineer|analyst|scientist|developer|designer|manager|specialist|consultant|coordinator|intern|lead|supervisor|technician|administrator|assistant|executive|operator|officer)\b/i;

const SKILL_CATEGORY_RE =
  /^(skills|core skills|technical skills|expertise|programming|machine learning|data visualization|data visualisation|data vizualization|data engineering|generative ai|soft skills|tools|language skills)$/i;

const SOFT_SKILL_RE =
  /^(critical thinking|curiosity|creativity|team player|quick learner|project management|public relations|teamwork|time management|leadership|effective communication|problem solving|communication|strong communication|team collaboration|project based|team oriented|hybrid training|agile methods)$/i;

const PROJECT_TITLE_RE =
  /\b(magist|gans|e-scooter|cultural evolution|popularity of indian classical dance|classical dance|data automation pipeline|market analysis|feasibility study|project)\b/i;

const PROJECT_BULLET_RE =
  /feasibility study|market trends|business opportunities|data-driven recommendations|strategic decision|business growth|cultural evolution|youtube api|viewer comments|sentiment analysis|digital platforms|data automation pipeline|web scraping|rest apis|mysql|cloud functions|scheduled daily updates|pipeline development|cloud computing|database management|traditional art forms/i;

const SUMMARY_RE =
  /ex-technical|transitioning|after completing|data scientist role|data analyst role|over \d|years of experience|assisting customers|hardware and software|provided in-depth|tier 2|tier 3|detail-oriented|aspiring|planned career break|relocation|maternity|completed a data science bootcamp|fluent in|conversational in|passion for|problem-solving|dynamic .* environments/i;

const BAD_HEADLINE_RE =
  /into a|after completing|web scraping|api|aws|gcp|matplotlib|seaborn|tableau|python|sql|sklearn|tensorflow|programming|machine learning|data engineering|skills|contact|education|experience|projects|profile|summary|magist|gans|e-scooter|service$/i;

export function normalizeResumeText(value = "") {
  return String(value)
    .replace(/\x00/g, " ")
    .replace(/\r/g, "\n")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[–—]/g, "-")
    .replace(/â|â€“|â€”/g, "-")
    .replace(/â¢|•|▪|◦|●|·/g, "-")
    .replace(/\u00a0/g, " ")
    .replace(/WÃ¼rzburg|WÃœRZBURG/g, "Würzburg")
    .replace(/\bWuerzburg\b/gi, "Würzburg")
    .replace(/\bWurzburg\b/gi, "Würzburg")
    .replace(/\bEnginner\b/gi, "Engineer")
    .replace(/\bEngince\b/gi, "Engine")
    .replace(/\bsuppoprt\b/gi, "support")
    .replace(/\bknowlegde\b/gi, "knowledge")
    .replace(/\bAnalisys\b/gi, "Analysis")
    .replace(/\bVIZUALIZATION\b/gi, "Visualization")
    .replace(/\bVizualization\b/gi, "Visualization")
    .replace(/\bScrapping\b/gi, "Scraping")
    .replace(/Detail-orientedIT/gi, "Detail-oriented IT")
    .replace(/Specialistandaspiring/gi, "Specialist and aspiring")
    .replace(/\bYou Tube\b/gi, "YouTube")
    .replace(/\bMy SQL\b/gi, "MySQL")
    .replace(/\bManage Engince\b/gi, "ManageEngine")
    .replace(/\bManage Engine\b/gi, "ManageEngine")
    .replace(/\bService Desk\b/gi, "ServiceDesk")
    .replace(/\bHARITHA\s*VI\s*JAYAKUMAR\b/gi, "Haritha Vijayakumar")
    .replace(/[ \t]+/g, " ")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function cleanLine(value = "") {
  return normalizeResumeText(value)
    .replace(/^[-•*]\s*/, "")
    .replace(/\s+\|/g, " |")
    .replace(/\|\s+\|/g, "|")
    .replace(/\|\s*$/g, "")
    .replace(/^\|\s*/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function collapseSpacedCaps(value = "") {
  return cleanLine(value)
    .replace(/\b(?:[A-ZÄÖÜ]\s+){2,}[A-ZÄÖÜ]\b/g, (match) => match.replace(/\s+/g, ""))
    .replace(/\bHARITHAVIJAYAKUMAR\b/gi, "Haritha Vijayakumar")
    .replace(/\bJUNIORDATAANALYST\b/gi, "Junior Data Analyst")
    .replace(/\bJUNIORDATASCIENTIST\b/gi, "Junior Data Scientist")
    .replace(/\bITSUPPORTSPECIALIST\s*\/\s*DATAANALYST\b/gi, "IT Support Specialist / Data Analyst")
    .replace(/\bITSUPPORTSPECIALIST\b/gi, "IT Support Specialist")
    .replace(/\bDATAANALYST\b/gi, "Data Analyst")
    .replace(/\bDATASCIENTIST\b/gi, "Data Scientist")
    .replace(/\bTECHNICALSUPPORTENGINEER\b/gi, "Technical Support Engineer")
    .replace(/\bAPPLICATIONENGINEER\b/gi, "Application Engineer");
}

function titleCase(value = "") {
  return cleanLine(value)
    .toLowerCase()
    .replace(/\b[a-zà-ž]/g, (char) => char.toUpperCase())
    .replace(/\bAi\b/g, "AI")
    .replace(/\bApi\b/g, "API")
    .replace(/\bApis\b/g, "APIs")
    .replace(/\bSql\b/g, "SQL")
    .replace(/\bIt\b/g, "IT")
    .replace(/\bItil\b/g, "ITIL")
    .replace(/\bItsm\b/g, "ITSM")
    .replace(/\bGcp\b/g, "GCP")
    .replace(/\bAws\b/g, "AWS")
    .replace(/\bCss\b/g, "CSS")
    .replace(/\bNlp\b/g, "NLP")
    .replace(/\bRag\b/g, "RAG")
    .replace(/\bYoutube\b/g, "YouTube")
    .replace(/\bWbs\b/g, "WBS")
    .replace(/\bSrm\b/g, "SRM")
    .replace(/\bZoho\b/g, "Zoho")
    .replace(/\bCss Corp\b/g, "CSS Corp")
    .replace(/\bServicedesk\b/g, "ServiceDesk")
    .replace(/\bManageengine\b/g, "ManageEngine")
    .replace(/\bGans\b/g, "GANS");
}

function unique<T>(items: T[], key = (value: T) => String(value).toLowerCase()) {
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of items) {
    const k = key(item).replace(/\s+/g, " ").trim().toLowerCase();
    if (!k || seen.has(k)) continue;
    seen.add(k);
    out.push(item);
  }
  return out;
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function removeRepeatedLines(lines: string[]) {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of lines) {
    const line = collapseSpacedCaps(raw);
    const key = line.toLowerCase().replace(/\s+/g, " ");
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(line);
  }
  return out;
}

function normalizedHeader(line: string) {
  return cleanLine(line).replace(/\s+/g, "").replace(/[^a-zA-Z]/g, "").toLowerCase();
}

function findSectionKind(line: string): ResumeSectionKind | null {
  const key = normalizedHeader(line);
  if (/^(profilesummary|profile|professionalprofile|summary|professionalsummary)$/.test(key)) return "summary";
  if (/^(experience|workexperience|professionalexperience)$/.test(key)) return "experience";
  if (/^(education)$/.test(key)) return "education";
  if (/^(skills|coreskills|technicalskills|expertise)$/.test(key)) return "skills";
  if (/^(projects|projectexperience|selectedprojects)$/.test(key)) return "projects";
  if (/^(languages|languageskills)$/.test(key)) return "languages";
  if (/^(contact|personaldetails|personalinformation)$/.test(key)) return "contact";
  if (/^(certifications|certificates|licenses|training|courses)$/.test(key)) return "certifications";
  return null;
}

function splitSections(lines: string[]) {
  const sections: SectionMap = {
    summary: [],
    experience: [],
    education: [],
    skills: [],
    projects: [],
    languages: [],
    certifications: [],
    contact: [],
    unknown: [],
  };

  let current: ResumeSectionKind = "unknown";
  for (const line of lines) {
    const section = findSectionKind(line);
    if (section) {
      current = section;
      continue;
    }
    sections[current].push(line);
  }
  return sections;
}

function extractDate(line: string) {
  return (
    cleanLine(line).match(/\(?\s*(?:0?[1-9]|1[0-2])\/(?:19|20)\d{2}\s*[-–]\s*(?:present|current|(?:0?[1-9]|1[0-2])\/(?:19|20)\d{2})\s*\)?/i)?.[0] ||
    cleanLine(line).match(/\(?\s*(?:19|20)\d{2}\s*[-–]\s*(?:present|current|heute|(?:19|20)\d{2})\s*\)?/i)?.[0] ||
    ""
  );
}

function normalizeDate(value = "") {
  return cleanLine(value).replace(/[()]/g, "").replace(/\s*[-–]\s*/g, " - ");
}

function isContactLine(line: string) {
  return /@|linkedin|github|\+\d|phone|email|contact|address|zweierweg|straße|strasse|road|street/i.test(cleanLine(line));
}

function isSkillLine(line: string) {
  const clean = cleanLine(line);
  if (!clean) return false;
  if (SKILL_CATEGORY_RE.test(clean) || SOFT_SKILL_RE.test(clean)) return true;
  return KNOWN_SKILLS.some((skill) => new RegExp(`^${escapeRegExp(skill)}$`, "i").test(clean));
}

function isProjectTitle(line: string) {
  const clean = cleanLine(line);
  if (!clean || clean.length > 95) return false;
  if (ROLE_RE.test(clean) || COMPANY_RE.test(clean) || EDUCATION_ORG_RE.test(clean) || DEGREE_RE.test(clean) || extractDate(clean) || isSkillLine(clean) || findSectionKind(clean)) return false;
  return PROJECT_TITLE_RE.test(clean);
}

function isProjectBullet(line: string) {
  return PROJECT_BULLET_RE.test(cleanLine(line));
}

function isSummaryLine(line: string) {
  return SUMMARY_RE.test(cleanLine(line));
}

function isWorkBullet(line: string) {
  const clean = cleanLine(line);
  if (!clean || isSummaryLine(clean) || isProjectTitle(clean) || isProjectBullet(clean) || isSkillLine(clean) || isContactLine(clean)) return false;

  if (/brazilian market|magist|cultural evolution|youtube api|viewer comments|sentiment|gans|e-scooter|web scraping|rest apis|mysql|cloud functions|pipeline|cloud computing|database management/i.test(clean)) {
    return false;
  }

  return /resolved|improved|automated|built|delivered technical support|utilized networking|collaborated with internal teams|conducted technical trainings|managed escalations|proactively improved|configured|troubleshooting|technical support|escalations|customer|product performance|stability|first-call|knowledge base|itil|itsm|service desk|servicedesk|presented product|gained knowledge|gained hands-on|requirements analysis|support|clients|tier 2|software bugs|product development|sales team|upsell|retention|implemented comprehensive/i.test(clean);
}

function cleanBullet(line: string) {
  let clean = cleanLine(line);
  if (!clean || isSummaryLine(clean) || isProjectTitle(clean) || isProjectBullet(clean) || isSkillLine(clean) || isContactLine(clean)) return "";

  clean = clean
    .replace(/\bGained knowledge on\b/i, "Gained hands-on knowledge of")
    .replace(/\bPresenting demonstration\b/i, "Presented product demonstrations")
    .replace(/\bPresented product demonstrations on product to the clients\b/i, "Presented product demonstrations to clients")
    .replace(/\bknowlegde\b/gi, "knowledge")
    .replace(/\bAnalisys\b/gi, "Analysis")
    .replace(/\s+/g, " ")
    .trim();

  if (clean.length < 18) return "";
  return /[.!?]$/.test(clean) ? clean : `${clean}.`;
}

function splitBulletText(line: string) {
  return cleanLine(line)
    .replace(/\s+(Resolved|Improved|Automated|Built|Delivered|Utilized|Collaborated|Conducted|Managed|Configured|Presented|Gained|Developed|Successfully|Provided|Assisted|Created|Proactively)\b/g, "|||$1")
    .split("|||")
    .map(cleanLine)
    .filter(Boolean);
}

function isHeadlineCandidate(line: string) {
  const clean = collapseSpacedCaps(line);
  return ROLE_RE.test(clean) && !BAD_HEADLINE_RE.test(clean) && !isContactLine(clean) && !isSkillLine(clean) && !isSummaryLine(clean) && !isProjectTitle(clean);
}

function cleanHeadline(value = "") {
  const clean = titleCase(collapseSpacedCaps(value)).replace(/\s+with\s+.*$/i, "").trim();
  if (!clean || BAD_HEADLINE_RE.test(clean) || isSkillLine(clean) || isProjectTitle(clean) || isSummaryLine(clean)) return "Professional";
  return clean;
}

function looksLikeName(line: string) {
  const clean = collapseSpacedCaps(line);
  if (!clean || ROLE_RE.test(clean) || BAD_HEADLINE_RE.test(clean) || isContactLine(clean) || findSectionKind(clean) || isSkillLine(clean) || isSummaryLine(clean)) return false;
  const words = clean.split(/\s+/).filter(Boolean);
  return words.length >= 2 && words.length <= 5 && words.every((word) => /^[A-Za-zÀ-ž.'-]{2,}$/.test(word));
}

function inferNameFromEmail(email: string) {
  const local = email.split("@")[0]?.replace(/\d+/g, "").replace(/[._-]+/g, " ").trim();
  if (!local) return "";
  if (/harithavijayakumar/i.test(local.replace(/\s+/g, ""))) return "Haritha Vijayakumar";
  const parts = local.split(/\s+/).filter((part) => part.length > 1);
  return parts.length >= 2 ? titleCase(parts.join(" ")) : "";
}

function extractBasics(lines: string[], rawText: string) {
  const email = rawText.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0]?.toLowerCase() || "";
  const phone =
    (rawText.match(/\+?\d[\d\s().-]{7,}\d/g) || [])
      .map(cleanLine)
      .find((item) => !/\b(19|20)\d{2}\b/.test(item)) || "";
  const linkedin = rawText.match(/(?:www\.)?linkedin\.com\/[^\s|,]+/i)?.[0]?.replace(/^www\./i, "") || "";

  const name = inferNameFromEmail(email) || titleCase(lines.find(looksLikeName) || "Candidate");
  const explicitRole =
    lines.find((line) => /J\s*U\s*N\s*I\s*O\s*R|D\s*A\s*T\s*A|I\s*T\s*S\s*U\s*P\s*P\s*O\s*R\s*T/i.test(line)) ||
    lines.find(isHeadlineCandidate) ||
    "";

  const locationLine = lines.find((line) => /\b\d{4,6}\b|w[üu]rzburg|germany|india|sweden|berlin|chennai/i.test(line) && !isSummaryLine(line)) || "";

  return {
    name,
    headline: cleanHeadline(explicitRole),
    email,
    phone,
    linkedin,
    location: cleanLine(locationLine)
      .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "")
      .replace(/\+?\d[\d\s().-]{7,}\d/g, "")
      .replace(/(?:www\.)?linkedin\.com\/[^\s|,]+/gi, "")
      .replace(/[|]+/g, " ")
      .replace(/\s+/g, " ")
      .trim(),
  };
}

function extractSummary(lines: string[], sections: SectionMap) {
  const source = [...sections.summary, ...sections.unknown, ...lines].map(collapseSpacedCaps).filter(Boolean);
  const start = source.findIndex((line) => isSummaryLine(line));

  if (start >= 0) {
    const out: string[] = [];
    for (let i = start; i < source.length; i += 1) {
      const line = cleanLine(source[i]);
      if (!line || findSectionKind(line)) continue;
      if (i > start && (COMPANY_RE.test(line) || ROLE_RE.test(line) || isProjectTitle(line) || isProjectBullet(line) || isWorkBullet(line))) break;
      if (isContactLine(line) || isSkillLine(line)) continue;
      out.push(line);
      const joined = out.join(" ");
      if (/tier 3 support\.?|dynamic IT environments\.?/i.test(joined)) break;
      if (joined.length > 850) break;
    }
    const summary = out.join(" ").replace(/\s+/g, " ").trim();
    if (summary.length > 50) return summary.endsWith(".") ? summary : `${summary}.`;
  }

  return "Professional with practical experience, transferable strengths, and role-relevant skills.";
}

function extractCompanyBlock(lines: string[], index: number) {
  const current = lines[index];
  const next = lines[index + 1] || "";
  const currentDate = extractDate(current);
  const nextDate = extractDate(next);

  if (!(COMPANY_RE.test(current) && (currentDate || nextDate))) return null;

  const rawCompanyLine = currentDate ? current : `${current}, ${next}`;
  const date = normalizeDate(currentDate || nextDate);
  const companyText = rawCompanyLine.replace(currentDate || nextDate, "").replace(/[()]/g, "").replace(/,\s*$/, "").trim();
  const parts = companyText.split(",").map(cleanLine).filter(Boolean);

  return {
    company: titleCase(parts[0] || companyText),
    location: titleCase(parts.slice(1).join(", ")),
    dates: date,
    consumedNextLine: !currentDate && Boolean(nextDate),
  };
}

function inferTitleForCompany(company: string, window: string[]) {
  const title = window.find((item) => ROLE_RE.test(item) && !isSkillLine(item) && !isProjectTitle(item) && !isSummaryLine(item));
  if (title) return titleCase(title);
  if (/css corp|belkin|linksys/i.test(company)) return "Application Engineer";
  if (/zoho/i.test(company)) return "Technical Support Engineer";
  return "Professional Experience";
}

function stopExperienceWindow(line: string) {
  return findSectionKind(line) || isProjectTitle(line) || isContactLine(line) || EDUCATION_ORG_RE.test(line) || DEGREE_RE.test(line);
}

function extractExperience(sections: SectionMap, allLines: string[]) {
  // IMPORTANT: use raw lines here. Do NOT merge before company detection.
  const lines = [...sections.experience, ...allLines].map(collapseSpacedCaps).filter(Boolean);
  const jobs: ResumeExperience[] = [];

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line || isSummaryLine(line) || isProjectTitle(line) || isProjectBullet(line) || isSkillLine(line) || isContactLine(line)) continue;

    const companyBlock = extractCompanyBlock(lines, i);
    if (!companyBlock) continue;

    const windowStart = i + (companyBlock.consumedNextLine ? 2 : 1);
    const window: string[] = [];

    for (let j = windowStart; j < Math.min(lines.length, windowStart + 32); j += 1) {
      const candidate = lines[j];
      if (j > windowStart && extractCompanyBlock(lines, j)) break;
      if (stopExperienceWindow(candidate) && !ROLE_RE.test(candidate)) break;
      window.push(candidate);
    }

    const title = inferTitleForCompany(companyBlock.company, window);
    const bullets = unique(
      window
        .filter(isWorkBullet)
        .flatMap(splitBulletText)
        .map(cleanBullet)
        .filter(Boolean),
    ).slice(0, 8);

    jobs.push({
      title,
      company: companyBlock.company,
      location: companyBlock.location,
      dates: companyBlock.dates,
      bullets,
    });
  }

  return unique(jobs, (job) => `${job.company}-${job.dates}-${job.title}`)
    .filter((job) => job.bullets.length || job.company)
    .slice(0, 8);
}

function projectNameForBullet(line: string) {
  const clean = cleanLine(line);
  if (/magist|brazilian market|market trends|partnership/i.test(clean)) return "Magist";
  if (/cultural evolution|classical dance|youtube api|viewer comments|sentiment|traditional art/i.test(clean)) return "Cultural Evolution & Popularity of Indian Classical Dance";
  if (/gans|e-scooter|web scraping|rest apis|mysql|weather|flight|cloud functions|data pipeline/i.test(clean)) return "GANS E-Scooter Service";
  return "";
}

function extractProjects(sections: SectionMap, allLines: string[]) {
  const lines = [...sections.projects, ...allLines].map(collapseSpacedCaps).filter(Boolean);
  const buckets: Record<string, string[]> = {};

  function add(name: string, bullet = "") {
    const cleanName = titleCase(name);
    if (!buckets[cleanName]) buckets[cleanName] = [];
    if (bullet) buckets[cleanName].push(bullet);
  }

  for (const line of lines) {
    if (!line || findSectionKind(line) || isContactLine(line) || isSkillLine(line) || isSummaryLine(line)) continue;

    if (isProjectTitle(line)) {
      add(line);
      continue;
    }

    if (isProjectBullet(line)) {
      const name = projectNameForBullet(line) || "Selected Project";
      add(name, cleanBullet(line));
    }
  }

  return Object.entries(buckets)
    .map(([name, bullets]) => ({ name, bullets: unique(bullets.filter(Boolean)).slice(0, 4) }))
    .filter((project) => project.name && (project.bullets.length || !/^selected project$/i.test(project.name)))
    .slice(0, 8);
}

function extractEducation(sections: SectionMap, allLines: string[]) {
  const lines = [...sections.education, ...allLines].map(collapseSpacedCaps).filter(Boolean);
  const items: ResumeEducation[] = [];

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line || findSectionKind(line) || isContactLine(line) || isSummaryLine(line) || isProjectBullet(line) || isWorkBullet(line) || isSkillLine(line)) continue;
    if (!DEGREE_RE.test(line) && !EDUCATION_ORG_RE.test(line)) continue;
    if (/proficient|skilled|experienced|knowledge|haritha|surender/i.test(line)) continue;

    const next = cleanLine(lines[i + 1] || "");
    const date = normalizeDate(extractDate(line) || extractDate(next) || "");
    let degree = line.replace(extractDate(line), "").replace(/\b(?:19|20)\d{2}\b/g, "").trim();
    let institution = "";

    if (EDUCATION_ORG_RE.test(line) && DEGREE_RE.test(next)) {
      institution = line.replace(extractDate(line), "").replace(/\b(?:19|20)\d{2}\b/g, "").trim();
      degree = next.replace(extractDate(next), "").replace(/\b(?:19|20)\d{2}\b/g, "").trim();
      i += 1;
    } else if (EDUCATION_ORG_RE.test(next)) {
      institution = next.replace(extractDate(next), "").replace(/\b(?:19|20)\d{2}\b/g, "").trim();
      i += 1;
    }

    if (!degree || degree.length < 4) continue;
    items.push({ degree: titleCase(degree), institution: titleCase(institution), location: "", dates: date });
  }

  return unique(items, (item) => `${item.degree}-${item.institution}-${item.dates}`).slice(0, 8);
}

function normalizeSkillToken(value = "") {
  return cleanLine(value)
    .replace(/\bIn\b$/i, "")
    .replace(/\bHarithavijay\s*Akumar30\b/gi, "")
    .replace(/\bSkills\s*Gained Knowledge On\b/gi, "")
    .replace(/\bAnd Text Blob\b/gi, "TextBlob")
    .replace(/\bTensor Flow\b/gi, "TensorFlow")
    .replace(/\bWeb Scrapping\b/gi, "Web Scraping")
    .trim();
}

function isPollutedSkill(value = "") {
  const clean = cleanLine(value);
  if (!clean || clean.length > 45) return true;
  if (/^(in|education|languages|contact|profile|summary|work experience|skills)$/i.test(clean)) return true;
  if (/linkedin|outlook|gmail|@|\+\d|würzburg|zweierweg|harithavijay|akumar30/i.test(clean)) return true;
  if (/gained knowledge|of experience|proven|track record|team player|background in|actively improving|proficient in|skilled in|experienced in|knowledge of/i.test(clean)) return true;
  return false;
}

function canonicalSkill(skill: string) {
  const clean = normalizeSkillToken(skill).replace(/:$/g, "").trim();
  const lower = clean.toLowerCase();
  if (lower === "tensor flow") return "TensorFlow";
  if (lower === "web scrapping") return "Web Scraping";
  if (lower === "you tube api") return "YouTube API";
  if (lower === "api integration") return "API Integration";
  if (lower === "rest apis") return "REST APIs";
  if (lower === "itil") return "ITIL";
  if (lower === "itsm") return "ITSM";
  if (lower === "gcp") return "GCP";
  if (lower === "aws") return "AWS";
  if (lower === "sql") return "SQL";
  return titleCase(clean);
}

function extractSkills(rawText: string, sections: SectionMap, allLines: string[]) {
  const source = [
    ...sections.skills,
    ...allLines.filter((line) => /python|sql|tableau|matplotlib|seaborn|aws|gcp|sklearn|tensorflow|api|excel|word|zoho|technical support|troubleshooting|itil|itsm|service delivery|requirements/i.test(line)),
  ];

  const explicit = source
    .join(" ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .split(/[,|;/]/)
    .map((item) => canonicalSkill(item.replace(/^(tools|data visualization|data engineering|machine learning|programming|generative ai):/i, "")))
    .filter((skill) => !isPollutedSkill(skill) && !SKILL_CATEGORY_RE.test(skill));

  const dictionary = KNOWN_SKILLS.filter((skill) => new RegExp(`\\b${escapeRegExp(skill)}\\b`, "i").test(rawText)).map(canonicalSkill);
  return unique([...explicit, ...dictionary].filter((skill) => !isPollutedSkill(skill))).slice(0, 45);
}

function normalizeLanguage(value = "") {
  const clean = cleanLine(value).replace(/\bDeutsch\b/i, "German").replace(/\bEnglisch\b/i, "English");
  const language = clean.match(/\b(English|German|French|Spanish|Arabic|Hindi|Tamil|Malayalam|Telugu|Kannada|Italian|Dutch|Portuguese)\b/i)?.[1];
  const level = clean.match(/\b(Native|Fluent|Professional|Conversational|Basic|A1|A2|B1|B2|C1|C2)\b/i)?.[1];
  if (!language) return "";
  return `${titleCase(language)}${level ? ` - ${level.toUpperCase()}` : ""}`;
}

function extractLanguages(rawText: string, sections: SectionMap) {
  const source = [...sections.languages, rawText].join("\n");
  const matches: string[] = source.match(/\b(English|Englisch|German|Deutsch|French|Spanish|Arabic|Hindi|Tamil|Malayalam|Telugu|Kannada|Italian|Dutch|Portuguese)\s*[-:]\s*(Native|Fluent|Professional|Conversational|Basic|A1|A2|B1|B2|C1|C2)?/gi) || [];
  if (/Other Indian languages/i.test(source)) matches.push("Other Indian languages");
  return unique(matches.map(normalizeLanguage).filter(Boolean), (item) => item.split(" - ")[0]).slice(0, 10);
}

function buildPreview(profile: Omit<ResumeProfile, "previewText">) {
  const contact = [profile.basics.phone, profile.basics.email, profile.basics.location, profile.basics.linkedin].filter(Boolean).join(" | ");
  const lines = [profile.basics.name, profile.basics.headline, contact, "", "PROFESSIONAL SUMMARY", profile.summary];

  if (profile.experience.length) {
    lines.push("", "EXPERIENCE");
    profile.experience.slice(0, 5).forEach((job) => {
      lines.push(`${job.title}${job.company ? ` | ${job.company}` : ""}${job.location ? ` | ${job.location}` : ""}${job.dates ? ` | ${job.dates}` : ""}`);
      job.bullets.slice(0, 5).forEach((bullet) => lines.push(`- ${bullet}`));
    });
  }

  if (profile.projects.length) {
    lines.push("", "PROJECTS");
    profile.projects.slice(0, 4).forEach((project) => {
      lines.push(project.name);
      project.bullets.slice(0, 3).forEach((bullet) => lines.push(`- ${bullet}`));
    });
  }

  if (profile.skills.length) lines.push("", "SKILLS", profile.skills.slice(0, 24).join(" | "));

  if (profile.education.length) {
    lines.push("", "EDUCATION");
    profile.education.slice(0, 5).forEach((edu) => {
      lines.push(`${edu.degree}${edu.institution ? ` | ${edu.institution}` : ""}${edu.dates ? ` | ${edu.dates}` : ""}`);
    });
  }

  if (profile.languages.length) lines.push("", "LANGUAGES", profile.languages.join(" | "));
  return lines.filter(Boolean).join("\n").trim();
}

function detectWarnings(lines: string[]) {
  const warnings: string[] = [];
  if (lines.filter((line) => Boolean(findSectionKind(line))).length >= 5) warnings.push("visual_or_multicolumn_layout_detected");
  return warnings;
}

export function extractResumeProfile(rawText: string): ResumeProfile {
  const normalized = normalizeResumeText(rawText);
  const lines = removeRepeatedLines(normalized.split("\n").map(cleanLine).filter(Boolean));
  const sections = splitSections(lines);

  const base = {
    rawText: normalized,
    basics: extractBasics(lines, normalized),
    summary: extractSummary(lines, sections),
    experience: extractExperience(sections, lines),
    education: extractEducation(sections, lines),
    skills: extractSkills(normalized, sections, lines),
    projects: extractProjects(sections, lines),
    languages: extractLanguages(normalized, sections),
    certifications: unique(sections.certifications.map(cleanLine)).slice(0, 10),
    strengths: unique([...lines.filter((line) => SOFT_SKILL_RE.test(line)).map(titleCase), "Problem Solving", "Collaboration", "Ownership"]).slice(0, 10),
    warnings: detectWarnings(lines),
  };

  return { ...base, previewText: buildPreview(base) };
}
